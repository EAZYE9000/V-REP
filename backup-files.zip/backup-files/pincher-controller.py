import vrep
import sys
import tensorflow as tf
import numpy as np
import threading
import time
# In v-rep add a cuboid, Right click on it in Scene Hierachy: Add->Associated child script->Threaded, and paste simExtRemoteApiStart(19999)
vrep.simxFinish(-1)
clientID=vrep.simxStart('127.0.0.1',19997,True,True,5000,5)
returnCode=vrep.simxStartSimulation(clientID, vrep.simx_opmode_oneshot)
if clientID != -1:
	print('Connected to remote API server')
else:
    print("Connection not successful")
    sys.exit("Error: Could not connect")

errorCode, phantom_joint_1 = vrep.simxGetObjectHandle(clientID,'PhantomXPincher_joint1',vrep.simx_opmode_oneshot_wait)
errorCode, phantom_joint_2 = vrep.simxGetObjectHandle(clientID,'PhantomXPincher_joint2',vrep.simx_opmode_oneshot_wait)
errorCode, phantom_joint_3 = vrep.simxGetObjectHandle(clientID,'PhantomXPincher_joint3',vrep.simx_opmode_oneshot_wait)
errorCode, phantom_joint_4 = vrep.simxGetObjectHandle(clientID,'PhantomXPincher_joint4',vrep.simx_opmode_oneshot_wait)
errorCode, phantom_gripper_joint = vrep.simxGetObjectHandle(clientID,'PhantomXPincher_gripperCenter_joint',vrep.simx_opmode_oneshot_wait)
errorCode, phantom_gripper_close_joint = vrep.simxGetObjectHandle(clientID,'PhantomXPincher_gripperClose_joint',vrep.simx_opmode_oneshot_wait)

# returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_1, x, vrep.simx_opmode_oneshot) original

def joint_force1(x):
    if x == 0:
        returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_1, 0.0, vrep.simx_opmode_oneshot)
    elif x == 1:
        returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_1, -0.7, vrep.simx_opmode_oneshot)
    elif x == 2:
        returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_1, -1.5, vrep.simx_opmode_oneshot)
def joint_force2(x):
    if x == 0:
        returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_2, 1.6, vrep.simx_opmode_oneshot)
    elif x == 1:
        returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_2, 1.35, vrep.simx_opmode_oneshot)
    elif x == 2:
        returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_2, 0.9, vrep.simx_opmode_oneshot)
def joint_force3(x):
    returnCode=vrep.simxSetJointTargetPosition(clientID,phantom_joint_3,x,vrep.simx_opmode_oneshot)
def joint_force4(x):
    returnCode=vrep.simxSetJointTargetPosition(clientID,phantom_joint_4,x,vrep.simx_opmode_oneshot)
def operate_gripper(x):
    # Set x to 0 to open, 1 to close the gripper
    if x == 0:
        returnCode_1, signalValue = vrep.simxGetIntegerSignal(clientID, "_gripperClose", vrep.simx_opmode_streaming)
        returnCode_2 = vrep.simxSetIntegerSignal(clientID, "_gripperClose", 0, vrep.simx_opmode_oneshot)
        returnCode_3 = vrep.simxSetJointTargetVelocity(clientID, phantom_gripper_close_joint, 2, vrep.simx_opmode_oneshot)
    elif x == 1:
        returnCode_1, signalValue = vrep.simxGetIntegerSignal(clientID, "_gripperClose", vrep.simx_opmode_streaming)
        returnCode_2 = vrep.simxSetIntegerSignal(clientID, "_gripperClose", 1, vrep.simx_opmode_oneshot)
        returnCode_3 = vrep.simxSetJointTargetVelocity(clientID, phantom_gripper_close_joint, -2000, vrep.simx_opmode_oneshot)

opmode=vrep.simx_opmode_blocking

# recieve video data
errorCode, cam_handle = vrep.simxGetObjectHandle(clientID, 'cam_1', vrep.simx_opmode_oneshot_wait)
s = returnCode, resolution, image = vrep.simxGetVisionSensorImage(clientID, cam_handle, 1, vrep.simx_opmode_streaming)
r = 0
#action_space = [operate_gripper(0),operate_gripper(1),joint_force1(0),joint_force1(1),joint_force1(2),joint_force2(0),joint_force2(2)]
""""
#def minus_reward():
def update(i):
  threading.Timer(1, update, [i]).start()
  sys.stdout.write(str(i)+'\r')
  sys.stdout.flush()
  #r -= 1
  i += 1
"""

def reward_calculation():
    if cuboid_position[2] > 0.1:
        # if the cuboid is on the ground, -0.1 to reward
        r - 0.1
    elif cuboid_position[2] < 0.99:
        # if the cuboid is in the air, -0.05 (so its less bad) to reward
        r - 0.05
    elif collisionState == True:
        print("Success!")
        r + 100

while True:
    # actions for neural net
    operate_gripper(0)
    joint_force1(2)
    joint_force2(0)

    # static forces
    joint_force3(0.0)
    joint_force4(1.75)

    # Cuboid0 handle
    res, cuboid0Handle = vrep.simxGetObjectHandle(clientID, "Cuboid0", vrep.simx_opmode_oneshot_wait)

    # Cuboid position
    returnCode, cuboid_position = vrep.simxGetObjectPosition(clientID, cuboid0Handle, -1, vrep.simx_opmode_streaming)

    # Landing pad collision detection
    returnCode,handle_1=vrep.simxGetCollisionHandle(clientID,"Collision0",vrep.simx_opmode_blocking)
    returnCode, collisionState=vrep.simxReadCollision(clientID,handle_1,vrep.simx_opmode_streaming)

    if cuboid_position[2] > 0.1:
        # if the cuboid is on the ground, -0.1 to reward
        r - 0.1
    elif cuboid_position[2] < 0.99:
        # if the cuboid is in the air, -0.05 (so its less bad) to reward
        r - 0.05
    elif collisionState == True:
        print("Success!")
        r + 100

    returnCode,handle_3=vrep.simxGetCollisionHandle(clientID,"Collision3",vrep.simx_opmode_blocking)
    returnCode, collisionState_3=vrep.simxReadCollision(clientID,handle_3,vrep.simx_opmode_streaming)

    if collisionState_3 == True:
        print("HIT THE WALL")

    #returnCode, resolution, image = vrep.simxGetVisionSensorImage(clientID, cam_handle, 1,
                                                                      #vrep.simx_opmode_streaming)
    #im = np.array(image, dtype=np.uint8)
    #returnCode = vrep.simxStopSimulation(clientID,vrep.simx_opmode_oneshot)
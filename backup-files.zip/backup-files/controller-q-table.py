import vrep
import sys
import numpy as np
from RL_brain import QLearningTable
import time

# In v-rep add a cuboid, Right click on it in Scene Hierachy: Add->Associated child script->Threaded, and paste simExtRemoteApiStart(19999)
"""vrep.simxFinish(-1)
clientID=vrep.simxStart('127.0.0.1',19997,True,True,5000,5)
returnCode=vrep.simxStartSimulation(clientID, vrep.simx_opmode_oneshot)
if clientID != -1:
	print('Connected to remote API server')
else:
    print("Connection not successful")
    sys.exit("Error: Could not connect")"""

clientID=vrep.simxStart('127.0.0.1',19997,True,True,5000,5)

errorCode, phantom_joint_1 = vrep.simxGetObjectHandle(clientID,'PhantomXPincher_joint1',vrep.simx_opmode_oneshot_wait)
errorCode, phantom_joint_2 = vrep.simxGetObjectHandle(clientID,'PhantomXPincher_joint2',vrep.simx_opmode_oneshot_wait)
errorCode, phantom_joint_3 = vrep.simxGetObjectHandle(clientID,'PhantomXPincher_joint3',vrep.simx_opmode_oneshot_wait)
errorCode, phantom_joint_4 = vrep.simxGetObjectHandle(clientID,'PhantomXPincher_joint4',vrep.simx_opmode_oneshot_wait)
errorCode, phantom_gripper_joint = vrep.simxGetObjectHandle(clientID,'PhantomXPincher_gripperCenter_joint',vrep.simx_opmode_oneshot_wait)
errorCode, phantom_gripper_close_joint = vrep.simxGetObjectHandle(clientID,'PhantomXPincher_gripperClose_joint',vrep.simx_opmode_oneshot_wait)
"""
def joint_force1(x):
    if x == 0:
        returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_1, 0.0, vrep.simx_opmode_oneshot)
    elif x == 1:
        returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_1, -0.7, vrep.simx_opmode_oneshot)
    elif x == 2:
        returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_1, -1.5, vrep.simx_opmode_oneshot)
def joint_force2(x):
    if x == 0:
        returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_2, 1.6, vrep.simx_opmode_oneshot)
    elif x == 1:
        returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_2, 1.35, vrep.simx_opmode_oneshot)
    elif x == 2:
        returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_2, 0.9, vrep.simx_opmode_oneshot)
def joint_force3(x):
    returnCode=vrep.simxSetJointTargetPosition(clientID,phantom_joint_3,x,vrep.simx_opmode_oneshot)
def joint_force4(x):
    returnCode=vrep.simxSetJointTargetPosition(clientID,phantom_joint_4,x,vrep.simx_opmode_oneshot)
def operate_gripper(x):
    # Set x to 0 to open, 1 to close the gripper
    if x == 0:
        returnCode_1, signalValue = vrep.simxGetIntegerSignal(clientID, "_gripperClose", vrep.simx_opmode_streaming)
        returnCode_2 = vrep.simxSetIntegerSignal(clientID, "_gripperClose", 0, vrep.simx_opmode_oneshot)
        returnCode_3 = vrep.simxSetJointTargetVelocity(clientID, phantom_gripper_close_joint, 2, vrep.simx_opmode_oneshot)
    elif x == 1:
        returnCode_1, signalValue = vrep.simxGetIntegerSignal(clientID, "_gripperClose", vrep.simx_opmode_streaming)
        returnCode_2 = vrep.simxSetIntegerSignal(clientID, "_gripperClose", 1, vrep.simx_opmode_oneshot)
        returnCode_3 = vrep.simxSetJointTargetVelocity(clientID, phantom_gripper_close_joint, -2, vrep.simx_opmode_oneshot)
"""
def operate_gripper_0():
    returnCode_1, signalValue = vrep.simxGetIntegerSignal(clientID, "_gripperClose", vrep.simx_opmode_streaming)
    returnCode_2 = vrep.simxSetIntegerSignal(clientID, "_gripperClose", 0, vrep.simx_opmode_oneshot)
    returnCode_3 = vrep.simxSetJointTargetVelocity(clientID, phantom_gripper_close_joint, 2, vrep.simx_opmode_oneshot)
def operate_gripper_1():
    returnCode_1, signalValue = vrep.simxGetIntegerSignal(clientID, "_gripperClose", vrep.simx_opmode_streaming)
    returnCode_2 = vrep.simxSetIntegerSignal(clientID, "_gripperClose", 1, vrep.simx_opmode_oneshot)
    returnCode_3 = vrep.simxSetJointTargetVelocity(clientID, phantom_gripper_close_joint, -2, vrep.simx_opmode_oneshot)

def joint_force1_0():
    returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_1, 0.0, vrep.simx_opmode_oneshot)
def joint_force1_1():
    returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_1, -0.7, vrep.simx_opmode_oneshot)
def joint_force1_2():
    returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_1, -1.5, vrep.simx_opmode_oneshot)

def joint_force2_0():
    returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_2, 1.6, vrep.simx_opmode_oneshot)
def joint_force2_1():
    returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_2, 1.35, vrep.simx_opmode_oneshot)
def joint_force2_2():
    returnCode = vrep.simxSetJointTargetPosition(clientID, phantom_joint_2, 0.9, vrep.simx_opmode_oneshot)

def joint_force3(x):
    returnCode=vrep.simxSetJointTargetPosition(clientID,phantom_joint_3,x,vrep.simx_opmode_oneshot)
def joint_force4(x):
    returnCode=vrep.simxSetJointTargetPosition(clientID,phantom_joint_4,x,vrep.simx_opmode_oneshot)

operate_gripper_1()
joint_force3(0.0)
joint_force4(1.75)

# recieve video data
errorCode, cam_handle = vrep.simxGetObjectHandle(clientID, 'cam_1', vrep.simx_opmode_oneshot_wait)
returnCode, resolution, image = vrep.simxGetVisionSensorImage(clientID, cam_handle, 1, vrep.simx_opmode_streaming)


# static forces
joint_force3(0.0)
joint_force4(1.75)

# Cuboid0 handle
res, cuboid0Handle = vrep.simxGetObjectHandle(clientID, "Cuboid0", vrep.simx_opmode_oneshot_wait)

# Cuboid position
returnCode, cuboid_position = vrep.simxGetObjectPosition(clientID, cuboid0Handle, -1, vrep.simx_opmode_streaming)

# Landing pad collision detection
returnCode, handle_1 = vrep.simxGetCollisionHandle(clientID, "Collision0", vrep.simx_opmode_blocking)
returnCode, collisionState = vrep.simxReadCollision(clientID, handle_1, vrep.simx_opmode_streaming)

returnCode, handle_2 = vrep.simxGetCollisionHandle(clientID, "Collision4", vrep.simx_opmode_blocking)
returnCode, collisionState_4 = vrep.simxReadCollision(clientID, handle_2, vrep.simx_opmode_streaming)

done = False
def reward_calculation():
    if cuboid_position[2] > 0.1:
        # if the cuboid is on the ground, -0.1 to reward
        r - 0.1
    elif cuboid_position[2] < 0.99:
        # if the cuboid is in the air, -0.05 (so its less bad) to reward
        r - 0.05
    elif collisionState_4 == True:
        r - 1.5
    """elif collisionState == True:
        print("Success!")
        r + 100
        done = True"""

s = image
r = 0
action_space = [operate_gripper_0,operate_gripper_1,joint_force1_0,joint_force1_2,joint_force2_0,joint_force2_2]
n_actions = len(action_space)
RL = QLearningTable(actions=list(range(n_actions)), action_space=action_space)

for episode in range(100):
    #returnCode = vrep.simxStopSimulation(clientID, vrep.simx_opmode_oneshot)
    vrep.simxFinish(-1)
    clientID = vrep.simxStart('127.0.0.1', 19997, True, True, 5000, 5)
    returnCode = vrep.simxStartSimulation(clientID, vrep.simx_opmode_oneshot)
    if clientID != -1:
        print('Connected to remote API server')
    else:
        print("Connection not successful")
        sys.exit("Error: Could not connect")
    errorCode, cam_handle = vrep.simxGetObjectHandle(clientID, 'cam_1', vrep.simx_opmode_oneshot_wait)
    returnCode, resolution, image = vrep.simxGetVisionSensorImage(clientID, cam_handle, 1, vrep.simx_opmode_streaming)
    s = image
    r = 0
    while True:
        action = RL.choose_action(str(s))
        reward_calculation()
        s_ = image
        RL.learn(str(s),action,r,str(s_))
        s = s_
        #print("In While Loop")

        returnCode, handle_1 = vrep.simxGetCollisionHandle(clientID, "Collision0", vrep.simx_opmode_blocking)
        returnCode, collisionState = vrep.simxReadCollision(clientID, handle_1, vrep.simx_opmode_streaming)

        returnCode, handle_3 = vrep.simxGetCollisionHandle(clientID, "Collision5", vrep.simx_opmode_blocking)
        returnCode, collisionState_3 = vrep.simxReadCollision(clientID, handle_3, vrep.simx_opmode_streaming)

        if collisionState_3 == True:
            print("SHE HIT THE FLOOR")
            r - 50
            break

        if collisionState == True:
            r + 100
            print("collide!")
            #returnCode = vrep.simxStopSimulation(clientID, vrep.simx_opmode_oneshot)
            break
    print("END OF TRIAL")
    returnCode = vrep.simxStopSimulation(clientID, vrep.simx_opmode_oneshot)
    time.sleep(6)